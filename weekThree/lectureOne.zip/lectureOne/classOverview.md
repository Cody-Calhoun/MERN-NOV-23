# MERN | Week Three Lecture One
#### November 7th 2023

## Housekeeping:
- Discussion Questions dues by 11:59 PM PDT
- Core assignment *Todo List* due by 11:59 PM PDT

## Recap:
- Lifted State
- Conditional Rendering

## Agenda:
- What is CRUD?
- How do we update?
- How do we delete?

